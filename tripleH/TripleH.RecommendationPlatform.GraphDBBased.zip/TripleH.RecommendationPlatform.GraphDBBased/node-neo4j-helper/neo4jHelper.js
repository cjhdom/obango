﻿var neo4j = require('neo4j');
var Q = require('q');
var Promise = require('bluebird')
var mecab = require('mecab-ya');
var Cypher;
var syntax;

var neo4jHelper = {
    isInit: false,
    clients: {}
};


neo4jHelper.Init = function (config) {

    if (config) {
        //replication
        if (Array.isArray(config)) {
            if (config.length > 0) {
                config.forEach(function (item, idx, list) {
                    console.log('[neo4j-HELPER] Initialization - %s', item.name);
                    neo4jHelper.clients[item.name] = {
                        connections: CreateNeo4jClient(item.addresses, item.port, item.username, item.password),
                        selectedIdx: 0
                    };
                });
            }
        }
        //standalone
        else {
            console.log('[neo4j-HELPER] Initialization - %s', config.name);
            neo4jHelper.clients[config.name] = {
                connections: CreateNeo4jClient(item.addresses, item.port, item.username, item.password),
                selectedIdx: 0
            };
        }
    }
};

neo4jHelper.GetClient = function (neo4jConnectionName) {
    //neo4j server
    if (!neo4jHelper.clients[neo4jConnectionName])
        throw Error('[neo4j-HELPER] Connection name error: %s', neo4jConnectionName);

    if (neo4jHelper.clients[neo4jConnectionName].connections.length > 1) {

        var currIdx = neo4jHelper.clients[neo4jConnectionName].selectedIdx;

        neo4jHelper.clients[neo4jConnectionName].selectedIdx++;

        if (neo4jHelper.clients[neo4jConnectionName].selectedIdx >= neo4jHelper.clients[neo4jConnectionName].connections.length)
            neo4jHelper.clients[neo4jConnectionName].selectedIdx = 0;

        return neo4jHelper.clients[neo4jConnectionName].connections[currIdx];
    }
    //standalone neo4j server
    else {
        return neo4jHelper.clients[neo4jConnectionName].connections[0];
    }
};

neo4jHelper.GetKeywords = function(paramData)
{
	syntax = Promise.promisify(mecab.nouns);
        syntax(paramData.keyword)
            .then(function (result) {
		return result.join().toString();
             });
}

neo4jHelper.GetResults = function (neo4jConnectionName, query, paramData) {
    	var db = neo4jHelper.GetClient(neo4jConnectionName);

	if (db.cypher) {
       	
	Cypher = Promise.promisify(db.cypher.bind(db));
      	
		return Cypher({
                 	query: query
                 	,params: paramData
        	});
     	}
};


function CreateNeo4jClient(addressesStr, port, username, password) {

    var clients = new Array();

    var addresses = addressesStr.split(",");
    port = port || 7474;

    for (var i = 0; i < addresses.length; i++) {
        var address = addresses[i].trim();
        var host = 'http://'.concat(address);
        var port = 7474;

        /*
        if (address.indexOf(':') > 0) {
            var portStr = address.substr(address.indexOf(':') + 1, address.length - address.indexOf(':'));
            if (portStr && !isNaN(portStr)) {
                port = parseInt(portStr);
            }
            host = address.substr(0, address.indexOf(':'));
        }
        */

        // var neo4jClient = neo4j.createClient(port, host);
        var url = host.concat(':', port);
        var neo4jClient = new neo4j.GraphDatabase({
            url: url,
            auth: {
                username: username,
                password: password
            }
        });

        //neo4jClient.on('error', function (err) {
        //    console.error("Neo4jClient Create error " + err);
        //});

        //ClientInit(neo4jClient, {
        //    address: addresses,
        //    db: db
        //});

        console.log('[neo4j-HELPER] neo4j Client is created - %s:%d', host, port);

        clients.push(neo4jClient);

    }
    return clients;
};


function ClientInit(client, config) {
    client.on('connect', function () {
        console.log('[REDIS-HELPER] Redis Client is connected - %s', config.address);

        client.select(config.db, function (err, res) {
            if (err) {
                console.error(err);
            }
            else {
                console.log('[REDIS-HELPER] Redis Client db selected - %s db %d', config.address, config.db);

                client._db_selected = true;
                client.emit('_db_selected');
            }
        });
    });
};

module.exports = neo4jHelper;
