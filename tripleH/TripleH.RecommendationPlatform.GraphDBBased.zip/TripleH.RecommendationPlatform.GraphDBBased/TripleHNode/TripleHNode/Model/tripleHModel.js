﻿var TripleHModel = {};

TripleHModel.GetRecommendedCategoryModel = {
    nickname: 'GetRecommendedCategoryModel',
    description: '',
    summary: 'Get Recommended Category Based on Item Names',
    params: [
        { KeyName: 'ItemName', KeyType: 'string', MaxLength: 1000, IsRequired: true, Desc: 'ItemName' },
    ]
};

TripleHModel.GetRecommendedItemModel = {
    nickname: 'GetRecommendedItemModel',
    description: '',
    summary: 'Get Recommended Items',
    params: [
        { KeyName: 'ItemName', KeyType: 'string', MaxLength: 1000, IsRequired: true, Desc: 'ItemName' }
        , { KeyName: 'SmallCateogoryCode', KeyType: 'string', MaxLength: 100, IsRequired: true, Desc: 'SmallCateogoryCode' }
    ]
};

TripleHModel.GetRecommendedKeywordModel = {
    nickname: 'GetRecommendedKeywordModel',
    description: '',
    summary: 'Get Recommended Keywords',
    params: [
        { KeyName: 'ItemName', KeyType: 'string', MaxLength: 1000, IsRequired: true, Desc: 'ItemName' }
        , { KeyName: 'SmallCateogoryCode', KeyType: 'string', MaxLength: 100, IsRequired: true, Desc: 'SmallCateogoryCode' }
    ]
};

module.exports = TripleHModel;