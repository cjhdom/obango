﻿var TripleHDac = require('../Dac/tripleHDac.js');
var TripleHBiz = {};


TripleHBiz.GetRecommendedCategory = function (itemName) {
    return TripleHDac.GetRecommendedCategory(itemName);
};

TripleHBiz.GetRecommendedItem = function (itemName, smallCateogoryCode) {
    return TripleHDac.GetRecommendedItem(itemName, smallCateogoryCode);
};

TripleHBiz.GetRecommendedKeyword = function (itemName, smallCateogoryCode) {
    return TripleHDac.GetRecommendedKeyword(itemName, smallCateogoryCode);
};

module.exports = TripleHBiz;