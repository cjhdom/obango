﻿
var config = require('./Config/tripleH.config');
var neo4j = require('neo4j');

var cluster = require('cluster');
//var mecab = require('mecab-ya');
//var mecab = require('mecab-ya');

//var text = '아버지가방에들어가신다';
/*
var text = 'this is the hackerton project';

mecab.pos(text, function (err, result) {
    console.log(err);
    console.log(result);
});

mecab.nouns(text, function (err, result) {
    console.log(result);
});

mecab.morphs(text, function (err, result) {
    console.log(result);
});

*/


//if (cluster.isMaster && process.env.DEBUG_MODE != 'ON') {

//    var CLUSTER_COUNT = config.ClusterCount || 1;

//    console.log('[Neo4j Cluster Start] configuration : \n%s', JSON.stringify(config));
//    console.log('[Neo4j Cluster Mode] cluster count : %d', CLUSTER_COUNT);

//    for (var i = 0; i < CLUSTER_COUNT; i++) {
//        cluster.fork();
//    }
//    cluster.on('exit', function (worker, code, signal) {
//        console.log('worker ' + worker.process.pid + ' died');
//    });

//    cluster.on('listening', function (worker, address) {
//        console.log("A worker is now connected to " + address.address + ":" + address.port);
//    });
//}
//else {
    var Q = require('q');

    global.NEO4J_CONFIG = config;

    var dacHelper;

    if (config.DbConnections.Type.toLowerCase() == 'neo4j') {
        dacHelper = require('../../node-neo4j-helper/neo4jHelper.js');
        dacHelper.Init(config.DbConnections.Connections);  
    }
    else {
        throw new Error('[Neo4j ERROR] DB connections configuration is required');
    }

    var WEB_PORT = config.port || 8000;

    var base = require('../../node-base-controller/baseController.js')({
        domain: config.domain,
	port: WEB_PORT,
        errorHandler: function (res, errorCode, error) {
            console.error('[%s] %s', new Date().toString(), error.stack);
        },
        appInfo: {
            title: 'NEO4J.API doc',
            description: 'Neo4j API.',
            version: '1.0.0'
        }
    });

    require('./Controller/route.js')(base);
//}

