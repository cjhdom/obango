﻿
var config = require('./Config/tripleH.config');
var neo4j = require('neo4j');

var cluster = require('cluster');
var mecab = require('mecab-ya');

var text = '한글 형태소 분석기 테스트'
mecab.morphs(text, function(err, result) {
  console.log (result);
});

mecab.nouns(text, function (err, result) {
    console.log(result);
});
