﻿var neo4jHelper = require('../../../node-neo4j-helper/neo4jHelper.js');

var TripleHDac = {};

TripleHDac.GetRecommendedCategory = function (itemName) {

    var query = "WITH SPLIT({keyword},',') AS SWords"
        + " MATCH(s:SMALL_CATEGORY)-[r:IS_CONSIST_OF]->(g:GOOD)-[r1:IS_SPLITTED_BY]->(k:GOOD_KEYWORD) WHERE k.KEYWORD in SWords WITH s, g, count(k) as list"
        + " MATCH(lc:LARGE_CATEGORY)-[h1:HAS]->(mc:MIDDLE_CATEGORY)-[h2:HAS] ->(sc:SMALL_CATEGORY {GDSC_CD: s.GDSC_CD })-[r2:IS_CONSIST_OF] ->() return lc, mc, sc, count(r2) as count order by count desc limit 10";

    var param = { keyword: itemName };

    //return neo4jHelper.GetResults('neo4j_read', query, param);
    return neo4jHelper.GetFinalResults('neo4j_read', query, param);
};

TripleHDac.GetRecommendedItem = function (itemName, smallCategory) {
    var query = "WITH SPLIT({keyword},',') AS SWords MATCH(s:SMALL_CATEGORY)-[r:IS_CONSIST_OF]->(g:GOOD)-[r1:IS_SPLITTED_BY]->(k:GOOD_KEYWORD) WHERE s.GDSC_CD = {category} and k.KEYWORD in SWords WITH s, g, count(k) as count"
        + " MATCH(good:GOOD{GD_NO: g.GD_NO })-[r2:SERIES_OF]->(snapshot:SNAPSHOT_TIME)-[r3:INVOKES] ->(cpcKeyword:CPC_KEYWORD)"
        + " return good, count(cpcKeyword) as count order by count desc limit 10";

    var param = {   
            keyword: itemName,
            category: smallCategory
    };

   return neo4jHelper.GetResults('neo4j_read', query, param);
};

TripleHDac.GetRecommendedKeyword = function (itemName, smallCategory) {

    var query =
        "WITH SPLIT({keyword}, ',') AS SWords"
        + " MATCH(s:SMALL_CATEGORY{GDSC_CD: {category} })-[r:IS_CONSIST_OF]->(g:GOOD)-[r1:IS_SPLITTED_BY] ->(k:GOOD_KEYWORD) WHERE k.KEYWORD in SWords WITH s, g, count(k) as count"
        + " MATCH(good:GOOD{GD_NO: g.GD_NO })-[r2:SERIES_OF]->(snapShot:SNAPSHOT_TIME)-[r3:INVOKES] ->(c:CPC_KEYWORD)"
        + " WITH c.KEYWORD_NAME as KEYWORD, SUM(30 - TOINT(r3.RANK)) as RANK"
        + " return KEYWORD, RANK order by RANK desc limit 10";

    var param = {
        keyword: itemName,
        category: smallCategory
    };

    return neo4jHelper.GetResults('neo4j_read', query, param);
};

module.exports = TripleHDac;