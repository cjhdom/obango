﻿
var Q = require('q');
var util = require('util');

var TripleHBiz = require('../Biz/tripleHBiz.js');

var TripleHController = {};

TripleHController.SetBaseController = function (base) {
    TripleHController.base = base;
};

TripleHController.GetRecommendedCategory = function (params) {

    if (params && params.ItemName.length <= 0) {
        throw TripleHController.base.Error(TripleHController.base.RESULTCODE_ENUM.VALIDATION_EXCEPTION, new Error('Item Name Cannot be nothing'));
    }

    //todo : create biz
    return TripleHBiz.GetRecommendedCategory(params.ItemName)
        .then(function (itemData) {
            return itemData;
        });
};

TripleHController.GetRecommendedItem = function (params) {
    if (params && params.ItemName.length <= 0) {
        throw TripleHController.base.Error(TripleHController.base.RESULTCODE_ENUM.VALIDATION_EXCEPTION, new Error('Item Name Cannot be nothing'));
    }

    if (params && params.SmallCateogoryCode.length <= 0) {
        throw TripleHController.base.Error(TripleHController.base.RESULTCODE_ENUM.VALIDATION_EXCEPTION, new Error('Small Category Cannot be nothing'));
    }

    //todo : create biz
    return TripleHBiz.GetRecommendedItem(params.ItemName, params.SmallCateogoryCode)
        .then(function (itemData) {
            return itemData;
        });
};

TripleHController.GetRecommendedKeyword = function (params) {
    if (params && params.ItemName.length <= 0) {
        throw TripleHController.base.Error(TripleHController.base.RESULTCODE_ENUM.VALIDATION_EXCEPTION, new Error('Item Name Cannot be nothing'));
    }

    if (params && params.SmallCateogoryCode.length <= 0) {
        throw TripleHController.base.Error(TripleHController.base.RESULTCODE_ENUM.VALIDATION_EXCEPTION, new Error('Small Category Cannot be nothing'));
    }
    //todo : create biz
    return TripleHBiz.GetRecommendedKeyword(params.ItemName, params.SmallCateogoryCode)
        .then(function (itemData) {
            return itemData;
        });
};


module.exports = TripleHController;