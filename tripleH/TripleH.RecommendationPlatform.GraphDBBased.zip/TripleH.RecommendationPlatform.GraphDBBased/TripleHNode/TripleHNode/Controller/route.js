﻿var homeController = require('./homeController.js');
var tripleHController = require('./tripleHController.js');
var tripleHModel = require('../Model/tripleHModel.js');

module.exports = function (base) {

    base.app.get('/serveralive/check_server_ip', homeController.CheckServerIp);

	/*
	 * MAPD APIs
	 * */
    tripleHController.SetBaseController(base);

    //base.Get('/Item/GetItemInfo', mapdController.GetItemInfo, mapdModel.GetItemInfoModel);
    base.Post('/Neo4j/GetRecommendedCategory', tripleHController.GetRecommendedCategory, tripleHModel.GetRecommendedCategoryModel);
    base.Post('/Neo4j/GetRecommendedItem', tripleHController.GetRecommendedItem, tripleHModel.GetRecommendedItemModel);
    base.Post('/Neo4j/GetRecommendedKeyword', tripleHController.GetRecommendedKeyword, tripleHModel.GetRecommendedKeywordModel);
};
