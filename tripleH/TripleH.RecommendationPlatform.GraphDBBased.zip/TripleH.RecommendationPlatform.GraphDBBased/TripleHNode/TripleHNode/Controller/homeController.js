﻿var os = require('os');

var neo4jHelper = require('../../../node-neo4j-helper/neo4jHelper.js');
var HomeController = {};

HomeController.CheckServerIp = function (req, res) {

    var addr = "";

    var neo4j_read = neo4jHelper.GetClient('neo4j_read');
    var neo4j_write = neo4jHelper.GetClient('neoj_write');

    //check redis Queue connection
    neo4j_read.ping(function (err, pong) {
        if (!err && pong == 'PONG') {

            mapdClient_write.ping(function (err, pong) {
                if (!err && pong == 'PONG') {

                    var ifaces = os.networkInterfaces();
                    for (var dev in ifaces) {
                        var alias = 0;
                        ifaces[dev].forEach(function (details) {
                            if (details.family == 'IPv4' && details.internal === false) {
                                addr = details.address;
                                ++alias;
                            }
                        });
                    }
                    res.status(200).send(addr);
                }
                else {
                    res.status(500).send(addr);
                }
            });
        }
        else {
            res.status(500).send(addr);
        }

    });
};

module.exports = HomeController;