﻿var Q = require('q');

var base = require('../baseController.js')({
	port: 8001,
	errorHandler: function (res, errorCode, error) {
		console.error('[%s] %s', new Date().toString(), error.stack);
	}
});

var SampleModelT = {
	nickname: 'SampleModelT',
	description: 'Test check server ip',
	summary: 'Test check server ip',
	params: [
		{ KeyName: 'seq', KeyType: 'int', Desc: 'sequence no', DefaultValue: 1, IsRequired: true },
		{ KeyName: 'name', KeyType: 'string', Desc: 'Name' }
	]
};

base.Get(
	'/Test/Get',
	function (params) {
		console.log('[get-test]' + JSON.stringify(params));
		return Q();
	},
	SampleModelT
);

base.Post(
	'/Test/Post', 
	function (params) {
		console.log('[post-test]' + JSON.stringify(params));
		return Q();
	},
	SampleModelT
);

