﻿var Q = require('q');
var util = require('util');

var validator = require('validator');
var express = require('express');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var swagger = require('swagger-node-express');

var app = express();

var path = require('path');

var WEB_PORT = 80;
var SWAGGER_PATH = '/swagger/api';

var baseController = {};

var Init = function (config) {
	
	WEB_PORT = config.port || WEB_PORT;

	baseController.app = app;
	baseController.preProcess = config.preProcess;
	baseController.errorHandler = config.errorHandler;
    baseController.domain = config.domain || util.format('http://%s:%s', require('os').hostname(), WEB_PORT);
	
	ROOT_PATH = config.rootPath || process.cwd();
	SWAGGER_PATH = config.swaggerPath || SWAGGER_PATH;
    
    app.use(cookieParser());
	app.use(bodyParser.json()); // for parsing application/json
	app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
	
	app.use('/', express.static(ROOT_PATH));
	app.engine('html', require('ejs').renderFile);
	app.set('views', ROOT_PATH);
	app.set('view engine', 'html');
	
	app.use(function (req, res, next) {
		res.header('Access-Control-Allow-Origin', '*');
		res.header('Access-Control-Allow-Methods', 'GET, POST');
		res.header('Access-Control-Allow-Headers', 'Content-Type, api_key, Authorization');
		next();
	});

	swagger.setAppHandler(app);
	
	swagger.errorHandler = function (req, res, ex) {
		var errCode = ex.errCode || RESULTCODE_ENUM.SWAGGER_UNKNOWN_EXCEPTION;
		ErrorHandler(res, errCode, ex);
	};
	swagger.configureSwaggerPaths('', SWAGGER_PATH, '');
	
	swagger.setApiInfo(config.appInfo);

	app.listen(WEB_PORT, function () {
		console.log('[WEB APPLICATION SERVER] Listening on port %d', WEB_PORT);
	});
	
	swagger.configure(baseController.domain);

	return baseController;
};


baseController.View = function (path, viewPath) {
	
	app.get(path, function (req, res) {
		res.render(viewPath);
	});
};

baseController.Get = function (path, fn, modelT) {

	if (modelT && modelT.params && Array.isArray(modelT.params) && modelT.params.length > 0) {
		
		var entities = new Array();

		for (var i = 0; i < modelT.params.length; i++) {
			if (modelT.params[i].Enum && Array.isArray(modelT.params[i].Enum)) {
				entities.push(swagger.queryParam(modelT.params[i].KeyName, modelT.params[i].Desc, modelT.params[i].KeyType, modelT.params[i].IsRequired, modelT.params[i].Enum, modelT.params[i].DefaultValue));
			}
			else {
				entities.push(swagger.queryParam(modelT.params[i].KeyName, modelT.params[i].Desc, modelT.params[i].KeyType, modelT.params[i].IsRequired, null, modelT.params[i].DefaultValue));
			}
		}
	}
	
	var swaggerApi = {
		spec: {
			path : path,
			summary : modelT ? modelT.summary : '',
			parameters : entities,
			nickname : modelT ? modelT.nickname : ''
		},
		action: function (req, res, next) {
			
			PreProcess(req, res, next);
			
			var params = ValidateModelEntity(req.query, res, modelT);
			
			if (params) {
				fn.prototype.httpContext = {
					req: req,
					res: res,
					next: next
				};
				
				new fn(params)
				.then(function (data) {
					if (!res._headerSent) {
						res.status(200).send({ ResultCode: RESULTCODE_ENUM.SUCCESS, Message: "Success", Data: data });
					}
					next();
					
				})
				.catch(function (ex) {
					var errCode = ex.errCode || RESULTCODE_ENUM.UNKNOWN_EXCEPTION;
					ErrorHandler(res, errCode, ex);
					next(ex);
				});
			}
		}
	};
	
	swagger.addGet(swaggerApi);
    swagger.configure(baseController.domain);
};

baseController.Post = function (path, fn, modelT) {
	
	if (modelT && modelT.params && Array.isArray(modelT.params) && modelT.params.length > 0) {
		
		var swaggerModel = {};
		swaggerModel[modelT.nickname] = {
			id: modelT.nickname,
			description: modelT.description,
			required: [],
			properties: {
			}
		};

		for (var i = 0; i < modelT.params.length; i++) {

			if (modelT.params[i].KeyType == 'object') {
				
				var childModel = {};
				childModel[modelT.nickname + '_' + modelT.params[i].KeyName] = {
					id: modelT.nickname + '_' + modelT.params[i].KeyName,
					properties: {}
				}

				swagger.addModels({
					models: childModel				
				});
				
				swaggerModel[modelT.nickname].properties[modelT.params[i].KeyName] = {
					$ref: modelT.nickname + '_' + modelT.params[i].KeyName,
					description: modelT.params[i].Desc
				}
			}
			else {
				swaggerModel[modelT.nickname].properties[modelT.params[i].KeyName] = {
					type: modelT.params[i].KeyType,
					description: modelT.params[i].Desc,
					defaultValue: modelT.params[i].DefaultValue
				}
			}
			
			if (modelT.params[i].Enum && Array.isArray(modelT.params[i].Enum)) {
				swaggerModel[modelT.nickname].properties[modelT.params[i].KeyName].enum = modelT.params[i].Enum;
			}

			if (modelT.params[i].IsRequired) {
				swaggerModel[modelT.nickname].required.push(modelT.params[i].KeyName);
			}
		}
		
		swagger.addModels({
			models: swaggerModel
		});
		
		var entities = new Array();
		entities.push(swagger.bodyParam(modelT.nickname, modelT.description, modelT.nickname));

	}

	var swaggerApi = {
		spec: {
			path : path,
			summary : modelT ? modelT.summary : '',
			parameters : entities,
			nickname : modelT ? modelT.nickname : ''
		},
		action: function (req, res, next) {
			
			PreProcess(req, res, next);
			
			var params = ValidateModelEntity(req.body, res, modelT);
			
			if (params) {
				fn.prototype.httpContext = {
					req: req,
					res: res,
					next: next
				};
				
				new fn(params)
				.then(function (data) {
					if (!res._headerSent) {
						res.status(200).send({ ResultCode: RESULTCODE_ENUM.SUCCESS, Message: "Success", Data: data });
					}
					next();
				})
				.catch(function (ex) {
					var errCode = ex.errCode || RESULTCODE_ENUM.UNKNOWN_EXCEPTION;
					ErrorHandler(res, errCode, ex);
					next(ex);
				});
			}
		}
	};

	swagger.addPost(swaggerApi);
    swagger.configure(baseController.domain);
	
};

baseController.Error = function (errCode, err) {
	err.errCode = errCode;
	return err;
};

var PreProcess = function (req, res, next) {
	if (baseController.preProcess && typeof baseController.preProcess) {
		baseController.preProcess(req, res, next);
	}
};

var ErrorHandler = function (res, errorCode, err) {
	
	if (!res._headerSent) {
		res.status(500).send({ ResultCode: errorCode, Message: err.message, Data: null });
	}
	
	if (baseController.errorHandler && typeof baseController.errorHandler == 'function') {
		baseController.errorHandler(res, errorCode, err);
	}

	return;
};

var ValidateModelEntity = function (reqParams, res, modelT) {
	
	var result = {};

	try {
		if (modelT && modelT.params && Array.isArray(modelT.params) && modelT.params.length > 0) {
			for (var i = 0; i < modelT.params.length; i++) {
				
				var reqParamValue = reqParams[modelT.params[i].KeyName];
				var parseParamValue = undefined;
				
				if (reqParamValue != null && reqParamValue != undefined) {
					var modelParamType = modelT.params[i].KeyType;
					
					if (modelT.params[i].Enum && Array.isArray(modelT.params[i].Enum)) {
						if (modelT.params[i].Enum.indexOf(reqParamValue) < 0)
							throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(enum) type error', modelT.params[i].KeyName)));
					}

					switch (modelParamType) {
						case DATA_MODEL_TYPE.String:
							parseParamValue = reqParamValue;
							break;
						case DATA_MODEL_TYPE.Integer:
							if (validator.isInt(reqParamValue))
								parseParamValue = parseInt(reqParamValue);
							else
								throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) type error', modelT.params[i].KeyName, modelT.params[i].KeyType)));
							break;
						case DATA_MODEL_TYPE.Long:
							if (validator.isInt(reqParamValue))
								parseParamValue = parseInt(reqParamValue);
							else
								throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) type error', modelT.params[i].KeyName, modelT.params[i].KeyType)));
							break;
						case DATA_MODEL_TYPE.Float:
							if (validator.isFloat(reqParamValue))
								parseParamValue = parseFloat(reqParamValue);
							else
								throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) type error', modelT.params[i].KeyName, modelT.params[i].KeyType)));
							break;
						case DATA_MODEL_TYPE.Double:
							if (validator.isFloat(reqParamValue))
								parseParamValue = parseFloat(reqParamValue);
							else
								throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) type error', modelT.params[i].KeyName, modelT.params[i].KeyType)));
							break;
						case DATA_MODEL_TYPE.Boolean:
							if (validator.isBoolean(reqParamValue))
								parseParamValue = (reqParamValue.toLowerCase() == 'true');
							else
								throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) type error', modelT.params[i].KeyName, modelT.params[i].KeyType)));
							break;
						case DATA_MODEL_TYPE.DateTime:
							if (validator.isDate(reqParamValue))
								parseParamValue = new Date(reqParamValue);
							else
								throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) type error', modelT.params[i].KeyName, modelT.params[i].KeyType)));
							break;
						case DATA_MODEL_TYPE.Array:
							if (Array.isArray(reqParamValue))
								parseParamValue = reqParamValue;
							else
								throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) type error', modelT.params[i].KeyName, modelT.params[i].KeyType)));
							break;
						case DATA_MODEL_TYPE.Object:
							if (typeof reqParamValue === 'object')
								parseParamValue = reqParamValue;
							else
								throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) type error', modelT.params[i].KeyName, modelT.params[i].KeyType)));
							break;
						default:
							parseParamValue = reqParamValue;
					}
				}
				else {
					if (modelT.params[i].IsRequired) {
						throw baseController.Error(RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, new Error(util.format('%s(%s) is required', modelT.params[i].KeyName, modelT.params[i].KeyType)));
					}
				}

				result[modelT.params[i].KeyName] = parseParamValue;		
			}
		}
	}
	catch (err) {
		return ErrorHandler(res, RESULTCODE_ENUM.INPUT_DATA_EXCEPTION, err);
	}
	return result;
};

var RESULTCODE_ENUM = {
	SUCCESS: 1,
	UNKNOWN_EXCEPTION: -901,
	SWAGGER_UNKNOWN_EXCEPTION: -902,    
	INPUT_DATA_EXCEPTION: -910,
	VALIDATION_EXCEPTION: -920,
	DATABASE_EXCEPTION: -930,
	CACHE_EXCEPTION: -940,
	BIZ_EXCEPTION : -950
};

var DATA_MODEL_TYPE = {
	Integer: 'int',
	Long: 'long',
	Float: 'float',
	Double: 'double',
	Boolean: 'boolean',
	String: 'string',
	DateTime: 'date',
	Array: 'array',
	Object: 'object',
};

baseController.RESULTCODE_ENUM = RESULTCODE_ENUM;

module.exports = Init;
