node-base-controller
====================

This is a node web server library for REST API Framework based on [Express(4.x)](http://promises-aplus.github.com/promises-spec "Express").  
Easy use and define api action for Swagger API automatically.  
Handling error using promise pattern with Q and response final result.  
Validation request by defined model in advance.  


##Using based library
 - express
 - swagger-node-express
 - q


##Getting Started
###Quick Launch


Download node-base-controller source from Git and copy to node_modules directory located on your execution project.
Run node-base-contriller with configuration of your web service.

```javascript
	var base = require('node-base-controller')({
		//Swagger API App Information
		appInfo: {			
			title: 'Your service title',
			description: 'Your service description',
			version: 'Your service version'
		},

		//Swagger api url (Default /swagger/api)
		swaggerPath: '/swagger/api',

		//Web server listening port (Default 8001)
		port: 8001, 

		//Running process root path (Default process.cwd())
		//Notice windows/linux path format
		rootPath: process.cwd(), //Use this if you want to change static folder root path

		//Error Handler (Optional)
		errorHandler: function (res, errorCode, error) {
			//To write your error handler
		},

		//Pre Process (Optional)
		preProcess: function (req, res, next) {
			//To write your pre process, before start action
		}
	});

```
If you want to install with NPM, Check below instruction.
<p style="color:#ff0000;">Notice the released package might not have been Latest version</p>
[Install Npm (prm.ebaykorea.com)](http://wiki.ebaykorea.com/display/PRM/Install+npm+Package "how to install prm npm")
```
npm install node-base-controller
```

  

##Action & Model Function

### Define Model Function
```javascript
	var SampleRequestModel = {		
		nickname: 'SampleRequestModel',	//Swagger api data type model nickname
		description: '',				//Swagger api description
		summary: '',					//Swagger api summary
		params: [
			{ KeyName: 'param1', KeyType: 'int', Desc: '' },
			{ KeyName: 'param2', KeyType: 'string' },
			{ KeyName: 'param3', KeyType: 'date' }	//...
		]
	};
```
  
#### KeyType List
Choose one of the type list below, when you difine model params KeyType value.
```javascript
	var DATA_MODEL_TYPE = {
		Integer: 'int',
		Long: 'long',
		Float: 'float',
		Double: 'double',
		Boolean: 'boolean',
		String: 'string',
		DateTime: 'date'
	};
```

  
#### Model Parameter Keyword List
- KeyName(string) : Unique parameter key name
- KeyType ([DATA_MODEL_TYPE](http://github.ebaykorea.com/org-package/node-base-controller#keytype-list "DATA_MODEL_TYPE")) : Type of parameter
- Desc (string) : Swagger data type description (available html syntax)
- IsRequired (boolean) : Parameter require check
- MaxLength (int) : Parameter length check
- DefaultValue (object) : Default parameter value


  

### Define Action Function
The GET method param object will be binded by url query string parser and POST method is by body parser.
```javascript
	var SampleAction = function (param) {
		//To do
		var result = 'Your result data using param(parsed json object)';
		return Q(result);
	};
```

### Map your routing uri
```javascript
	var base = require('node-base-controller')(config);

	base.Get('/YourGetRoutingUri', actionFunction, requestModelFunction);
	base.Post('/YourPostRoutingUri', actionFunction, requestModelFunction);
```

##Validation of RequestModel
**KeyType**
- Number type check : Integer, Long, Float, Double
- Boolean type check : Boolean
- DateTime format check : DateTime
  
**IsRequired**
- Nullable check : null, undefined, ""
  
**MaxLength**
- String length check
  


##Defined Response Model

```javascript
	var Response = {
		ResultCode: RESULTCODE_ENUM,
		Message: string,
		Data: object
	};
```

ResultCode
```javascript
	var RESULTCODE_ENUM = {
		SUCCESS: 1,
		UNKNOWN_EXCEPTION: -901,
		SWAGGER_UNKNOWN_EXCEPTION: -902,    
		INPUT_DATA_EXCEPTION: -910,
		VALIDATION_EXCEPTION: -920,
		DATABASE_EXCEPTION: -930,
		CACHE_EXCEPTION: -940,
		BIZ_EXCEPTION : -950
	};
```

  
##Swagger API
If you use node-base-controller GET/POST api, swagger api will be applied automatically.

Default swagger api url
```
	http://localhost:8001/swagger/api
```

You can check with Swagger UI([petstore sample](http://petstore.swagger.io/ "Swagger UI Petstore"))
```
	http://petstore.swagger.io/?url=http//localhost:8001/swagger/api	
```

  
##Error Handling

Set your ErrorHandler function. This will be code called after response.
```javascript
	var MyErrorHandler = function (res, errorCode, error) {
		//To do
		console.error('[%s] %s', new Date().toString(), error.stack);
	};

	var base = require('node-base-controller')({
		...
		errorHandler: MyErrorHandler
		...
	});
```

  
  
##HttpContext Reference
You can use express object req,res,next in the prototype action function.
```javascript
	var SampleAction = function (param) {
		
		var request = this.httpContext.req;
		var response = this.httpContext.res;
		var next = this.httpContext.next;

		...
	};
```

  

##AOP Function
###PreProcess
Insert your AOP code before executing action function.
```javascript
	var MyPreProcess = function (req, res, next) {
		//To do
		Log(req);
	};

	var base = require('node-base-controller')({
		...
		preProcess: MyPreProcess
		...
	});
```
