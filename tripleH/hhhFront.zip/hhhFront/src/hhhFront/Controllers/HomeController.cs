﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace hhhFront.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Jsondata1()
        {

            return View();
        }

        public IActionResult Jsondata2()
        {

            return View();
        }

        public IActionResult Jsondata3()
        {

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
