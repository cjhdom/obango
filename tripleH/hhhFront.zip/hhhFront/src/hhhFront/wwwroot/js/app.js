﻿$(function () {
    $('#bCate').click(function () {
        if ($('#keyword').val() != '') {
            d3.selectAll("svg > *").remove();
            getData(1);
        } else {
            alert("chekck your keyword!");
        }
    });
    $('#bItem').click(function () {
        if ($('#keyword').val() != '' && $('#categorycode').val() != '') {
            d3.selectAll("svg > *").remove();
            getData(2);
        } else {
            alert("chekck your keyword or category!");
        }

    });
    $('#bKey').click(function () {
        if ($('#keyword').val() != '' && $('#categorycode').val() != '') {
            d3.selectAll("svg > *").remove();
            getData(3);
        } else {
            alert("chekck your keyword or category!");
        }
    });
});

function setCategory(scate) {
    if (typeof scate != 'undefined')
        $('#categorycode').val(scate);
}

var url = "";
var urlparam = "";

var debugon = false;

var url1 = "http://52.185.145.156:8000/Neo4j/GetRecommendedCategory";
var url2 = "http://52.185.145.156:8000/Neo4j/GetRecommendedItem";
var url3 = "http://52.185.145.156:8000/Neo4j/GetRecommendedKeyword";

if (debugon) {
    url1 = "/Home/Jsondata1";
    url2 = "/Home/Jsondata2";
    url3 = "/Home/Jsondata3";
}
 

var keyword = "";
var categorycode = "";

var diameter = 600,
    format = d3.format(",d"),
    color = d3.scale.category20c();

var bubble = d3.layout.pack()
    .sort(null)
    .size([diameter, diameter])
    .padding(1.5);

var svg = d3.select("body").append("svg")
    .attr("width", diameter)
    .attr("height", diameter)
    .attr("class", "bubble");

var color = d3.scale.category10();

var tooltip = d3.select("body")
    .append("div")
    .style("position", "absolute")
    .style("z-index", "10")
    .style("visibility", "hidden")
    .style("color", "white")
    .style("padding", "8px")
    .style("background-color", "rgba(0, 0, 0, 0.75)")
    .style("border-radius", "6px")
    .style("font", "15px sans-serif")
    .text("tooltip");



function getData(apiType) {
    keyword = $("#keyword").val();
    categorycode = $("#categorycode").val();
    switch (apiType) {
        case 1:
            url = url1;
            urlparam = { ItemName: keyword };
            $("#bInfo")[0].innerText = "Category Recommendation"
            $("#bInfo").attr('class', 'btn btn-primary');
            break;
        case 2:
            url = url2;
            urlparam = { ItemName: keyword, SmallCateogoryCode: categorycode };
            $("#bInfo")[0].innerText = "Item Recommendation"
            $("#bInfo").attr('class', 'btn btn-success');
            break;
        case 3:
            url = url3;
            urlparam = { ItemName: keyword, SmallCateogoryCode: categorycode };
            $("#bInfo")[0].innerText = "Keyword Recommendation"
            $("#bInfo").attr('class', 'btn btn-warning');
            break;
    }

    d3.xhr(url)
        .header("Content-Type", "application/json")
        .post(
            JSON.stringify(urlparam),
            function (err, rawData) {
                var root = JSON.parse(rawData.response);

                var node = svg.selectAll(".node")
                    .data(bubble.nodes(classes(root, apiType))
                    .filter(function (d) {
                        return !d.children;
                    }))
                    .enter().append("g")
                    .attr("class", "node")
                    .attr("transform", function (d) {
                        return "translate(" + d.x + "," + d.y + ")";
                    });


                node.append("circle")
                    .attr("r", function (d) {
                        return d.r;
                    })
                    .style("fill", function (d) {
                        return color(d.packageName);
                    })
                    .on("mouseover", function (d) {
                        tooltip.text(d.className + ": " + format(d.value));
                        tooltip.style("visibility", "visible");
                    })
                    .on("mousemove", function () {
                        return tooltip.style("top", (d3.event.pageY - 10) + "px").style("left", (d3.event.pageX + 10) + "px");
                    })
                    .on("mouseout", function () {
                        return tooltip.style("visibility", "hidden");
                    });


                node.append("a")
                    .attr("xlink:href", function (d) {
                        return "javascript:setCategory(" + d.categorycode + ");";
                    })
                    .append("text")
                        .each(function (d) {
                            categorycode
                            if (apiType == 1) {
                                var str = d.className.substring(0, d.r / 5) + "|" + d.categorycode + "|" + d.value;

                            } else if (apiType == 2) {
                                var str = d.className.substring(0, d.r / 5) + "|" + d.gdno + "|" + d.value;
                            } else {
                                var str = d.className.substring(0, d.r / 5) + "|" + d.value;
                            }
                            var arr = str.split("|");
                            if (arr != undefined) {
                                for (i = 0; i < arr.length; i++) {
                                    d3.select(this).append("tspan")
                                    .text(arr[i])
                                    .attr("dy", i ? "1.2em" : 0)
                                    .style("font-weight", "bold")
                                    .attr("x", 0)
                                    .attr("text-anchor", "middle")
                                    .attr("pointer-event", "none")
                                    .attr("class", "tspan" + i);
                                }
                            }
                        });

            }
        );

}


//d3.json("/home/Jsondata", function (error, root) {
//    var node = svg.selectAll(".node")
//        .data(bubble.nodes(classes(root))
//            .filter(function (d) {
//                return !d.children;
//            }))
//        .enter().append("g")
//        .attr("class", "node")
//        .attr("transform", function (d) {
//            return "translate(" + d.x + "," + d.y + ")";
//        });

//    node.append("circle")
//        .attr("r", function (d) {
//            return d.r;
//        })
//        .style("fill", function (d) {
//            return color(d.packageName);
//        })
//        .on("mouseover", function (d) {
//            tooltip.text(d.className + ": " + format(d.value));
//            tooltip.style("visibility", "visible");
//        })
//        .on("mousemove", function () {
//            return tooltip.style("top", (d3.event.pageY - 10) + "px").style("left", (d3.event.pageX + 10) + "px");
//        })
//        .on("mouseout", function () {
//            return tooltip.style("visibility", "hidden");
//        });

//    //node.append("text")
//    //    .attr("dy", ".3em")
//    //    .style("text-anchor", "middle")
//    //    .style("pointer-events", "none")
//    //    .text(function (d) {
//    //        return d.className.substring(0, d.r / 3) + " " + d.value;
//    //    });

//    node.append("text")
//        .each(function (d) {
//            var str = d.className.substring(0, d.r / 3)+ " " + d.value;
//            var arr = str.split(" ");
//            if (arr != undefined) {
//                for (i = 0; i < arr.length; i++){
//                    d3.select(this).append("tspan")
//                    .text(arr[i])
//                    .attr("dy", i ? "1.2em" : 0)
//                    .attr("x", 0)
//                    .attr("text-anchor", "middle")
//                    .attr("pointer-event", "none")
//                    .attr("class", "tspan" + i);
//                }
//            }
//        });
  
//});



// Returns a flattened hierarchy containing all leaf nodes under the root.
function classes(root, apiType) {
    var classes = [];

    //function recurse(name, node) {
    //    if (node.children) node.children.forEach(function (child) {
    //        recurse(node.name, child);
    //    });
    //    else classes.push({
    //        packageName: name,
    //        className: node.name,
    //        value: node.size
    //    });
    //}
    //recurse(null, root);

    var colorval = 0;
    if (root.ResultCode == 1) {
        root.Data.forEach(function (res) {
            colorval++;

            if (apiType == 1){
                classes.push({
                    packageName: colorval,
                    className: res.sc.properties.GDSC_NM,
                    categorycode: res.sc.properties.GDSC_CD,
                    value: res.count
                });
            } else if (apiType == 2) {
                classes.push({
                    packageName: colorval,
                    className: res.good.properties.GD_NM,
                    gdno: res.good.properties.GD_NO,
                    value: res.count
                });
            } else {
                classes.push({
                    packageName: colorval,
                    className: res.KEYWORD,
                    value: res.RANK
                });
            }
        });

    }
    return {
        children: classes
    };
}


d3.select(self.frameElement).style("height", diameter + "px");